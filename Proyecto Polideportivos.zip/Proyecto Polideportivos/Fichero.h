/*
 * Fichero.h
 *
 *  Created on: 23 mar 2023
 *      Author: pablo
 */

#ifndef FICHERO_H_
#define FICHERO_H_



#endif /* FICHERO_H_ */
