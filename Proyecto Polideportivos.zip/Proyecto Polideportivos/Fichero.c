/*
 * Fichero.c
 *
 *  Created on: 23 mar 2023
 *      Author: pablo
 */


